### Tema 1a APD

Pentru inceput, am facut 3 `struct`s, anume `input_file_for_mapper`, `mapper_args` si `reducer_args`.

Structura `input_file_for_mapper` m-a ajutat sa sortez mai usor fisierele de input pastrandu-le si id-ul. Sortarea lor a fost facuta descrescator dupa dimensiune. Astfel, thread-urile de tip mapper vor primi mai intai fisierele mai mari si vor lucra pe baza unei cozi, coada pe care folosesc si un mutex pentru a nu avea race condition.

Structurile `mapper_args` si `reducer_args` sunt argumentele primite de functiile pentru cele doua tipuri de threaduri.

Dupa ce un mapper ia fisierul din coada, acesta ii parcurge toate cuvintele, le "curata" (elimina orice caracter non-alfabetic din cuvinte) si le adauga in `local_map`. Cand un mapper termina cu un fisier, pune un lock si adauga `local_map` in `mapper_output`, care este impartit intre toti mapperii. Dupa aceea se intoarce la coada pentru un nou fisier.

La finalul executiei tuturor mapperilor dar si la inceputul executiei reducerilor am pus o bariera. Astfel ma asigur ca niciun reducer nu incepe executia pana nu sunt gata mapperii. Pentru accesul reducerilor la `mapper_output` se utilizeaza un mutex. Reducerul ia primul element din coada, anume un `unordered_map<string, int>`. Pentru fiecare element din acest `unordered_map` vom adauga in `reducer_output`.

`reducer_output` are tipul `unordered_map<int, unordered_map<string, vector<int>>>`, unde cheia `int` reprezinta un numar de la 0 la 25 (acesta corespunde literelor de la a la z, unde a este 0, b este 1, etc.), iar valoarea asociata reprezinta o mapare de la un cuvant la o lista cu id-urile fisierelor in care apare.

In `reducer_output` avem cuvintele organizate dupa prima litera, dar inca nu sunt sortate. Astfel, am pus o bariera la finalul popularii `reducer_output`, iar dupa aceasta am inceput procesarea paralela pentru `inverted_index`. In aceasta parte se face sortarea, fiecare thread reducer lucrand pe zone diferite din `reducer_output` (folosind `start` si `end`, calculate pe baza numarului de litere din alfabet, a id-ului reducerului si a numarului de reduceri).

Structura de date a ajuns in forma finala, dar trebuie sa si scriem in fisiere. Am pus o bariera la finalul adaugarilor in `inverted_index` si am pastrat numai un thread (anume cel cu `leader_id`) pentru scrierea in fisiere.
